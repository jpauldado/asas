<!DOCTYPE html>
<html>
	<head>
			<title>Apply now!</title>
			<meta charset="utf-8">
    		<meta name="viewport" content="width=device-width, initial-scale=1">
			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/bootstrap.css">
<style>
*{
	margin: 0;
	padding: 0;
}
[class*="col-4"]{
	margin-top: 2rem;
	padding: 1rem;
	background-color: #33b5e5;
	border:  2px solid #fff;
	color:  #fff;
	text-align:  center;
}
ul {
		top: 0;
		width: 100%;
  	list-style-type: none;
  	margin: 0;
  	padding: 0;
  	overflow: hidden;
}

li {
  	float: right;	
}
.navbar a{
	padding: 20px 50px 20px 50px;
	float: right;
}

li a {
  	display: block;
  	color: black;
  	text-align: center;
  	padding: 14px 16px;
  	text-decoration: none;
}
.active {
  	background-color: #4d82ff;
}

/* Change the link color to #111 (black) on hover */
li a:hover {
  background-color: #4d82ff;
}
h1{
	margin-top: 5rem;
	color:	#4d82ff ;
}
.slogan{
	color: white;
	background-color:  #4d82ff;
	height: 15rem;
	text-align: center;
}
input[type="submit"]{
  	border: solid white 1px;
  	color: black;
  	background-color: #33b5e5;
  	text-align: center;
  	text-decoration: none;
  	margin: 10px 2px;
  	cursor: pointer;
  	border-radius: 12px;
  	padding: 5px 50px;
}
p{
	text-align: left;
}
.footer{
	background-color: #33b5e5;
	width: 100% ;
	margin-top: 3rem;
}
td, th {
  text-align: left;
  padding: 8px;
}

</style>

	</head>
	<body>
		<div class="header">
			<div class="navbar">
				<ul>
					<li class="active" style="float:left;"><a href="#">End_Up</a></li>
  					<li><a href="#">Home</a></li>
  					<li><a href="#">Services</a></li>
  					<li><a href="#">For Hire</a></li>
  					<li><a href="#">About Us</a></li>
				</ul>
			</div>
		</div>
<h1>For Hire</h1>
	<div class="slogan">
		<br>
		<h2> Grow Your Career with Us</h2><br><br><br>
		<h4>We're looking for the skilled applicant for the FF:</h4>
	</div>
<div class="container px-4">
	<div class="row gx-5">
		<div class="col-4">
			<div class="p-3 border"><h3>CEO Content Writer</h3><br>
				<p><img src="images/check.png" width="25px"> Bachelor’s degree in English, journalism, communications, or a related field preferred<br>
					<p><img src="images/check.png" width="25px"> 3+ years of professional writing experience, especially with digital platforms<br>
						<p><img src="images/check.png" width="25px"> Familiarity with keyword placement and SEO<br></p>
							<p><img src="images/check.png" width="25px"> Portfolio of published work<br></p>
								<p><img src="images/check.png" width="25px"> Excellent grammar and writing skills<br></p>
									<p><img src="images/check.png" width="25px"> Able to multitask, prioritize, and manage time efficiently</p>
										<p><img src="images/check.png" width="25px"> Self-motivated and self-directed</p>
											<p><img src="images/check.png" width="25px"> Proficient with Microsoft Office Suite and Google Docs</p>
			<input type="submit" value="View More!"></div>
</div>
		<div class="col-4">
			<div class="p-3 border"><h3>Graphic Designer</h3><br>
				<p><img src="images/check.png" width="25px"> Bachelor's degree in graphic arts, design, communications, or related field<br>
					<p><img src="images/check.png" width="25px"> 3-5 years of experience in graphic design<br>
						<p><img src="images/check.png" width="25px"> Knowledge of layouts, graphic fundamentals, typography, print, and the web<br>
							<p><img src="images/check.png" width="25px"> Familiarity with HTML and CSS preferred<br>
								<p><img src="images/check.png" width="25px"> Knowledge of Adobe PhotoShop, Illustrator, Sketch, InDesign, and other graphic design software<br>
									<p><img src="images/check.png" width="25px"> Compelling portfolio of work over a wide range of creative projects<br>
										<p><img src="images/check.png" width="25px"> Strong analytical skills<br>
											<p><img src="images/check.png" width="25px"> Excellent eye for detail</p>
				<input type="submit" value="View More!"></div>
</div>
		<div class="col-4">
			<div class="p-3 border"><h3>Social Media Specalist</h3><br>
				<p><img src="images/check.png" width="25px"> Proven working experience in social media marketing or as a Digital Media Specialist<br>
					<p><img src="images/check.png" width="25px"> Excellent consulting, writing, editing (photo/video/text), presentation and communication skills<br>
						<p><img src="images/check.png" width="25px"> Demonstrable social networking experience and social analytics tools knowledge<br>
							<p><img src="images/check.png" width="25px"> Adequate knowledge of web design, web development, CRO and SEO<br>
								<p><img src="images/check.png" width="25px"> Knowledge of online marketing and good understanding of major marketing channels<br>
											<p><img src="images/check.png" width="25px"> BS in Communications, Marketing, Business, New Media or Public Relations</p>
				</p>
			<input type="submit" value="View More!"></div>
</div>
		</div>
	</div>
	<div class="footer">
		<table>
			<tr>
			<th>Partnership</th>
			<th>About Us</th>
			</tr>
			<tr>
				<td>Web Builder</td>
				<td>Our Product</td>
			</tr>
			<tr>
				<td>Social Media Market</td>
				<td>Testimonies</td>
			</tr>
			<tr>
				<td>Branding</td>
				<td>Careers</td>
			</tr>
		</table>

	</div>
</div>


	</body>
</html>